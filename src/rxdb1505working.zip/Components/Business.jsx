import React, { useEffect, useState } from "react";
import { getDatabase } from "../DB/initDatabase";
import { v4 as uuidv4 } from "uuid";

const Business = () => {
    const [name, setName] = useState("");
    const [businesses, setBusinesses] = useState([]);

    const fetchBusinesses = async () => {
        const db = await getDatabase();
        const collection = db.businesses;
        const allDocs = await collection.find().exec();
        setBusinesses(allDocs.map((doc) => doc.toJSON()));
    };

    const handleAddBusiness = async () => {
        if (!name.trim()) {
            alert("Enter Business Name");
            return;
        }
        const db = await getDatabase();
        const collection = db.businesses;

        const newBusiness = {
            id: uuidv4(),
            name: name.trim(),
        };

        await collection.insert(newBusiness);
        console.log("Business added:", newBusiness);

        setName(""); // Clear input
        fetchBusinesses();
    };

    useEffect(() => {
        fetchBusinesses();
    }, []);

    return (
        <div>
            <h3>Create Business</h3>
            <div>
                <input
                    type="text"
                    placeholder="Business Name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                />
                <button
                    onClick={handleAddBusiness}
                    style={{ marginLeft: "10px" }}
                >
                    Add Business
                </button>
            </div>
            <br />
            <div>
                <h3>Business List</h3>
                <ul>
                    {businesses.map((business) => (
                        <li key={business.id}>{business.name}</li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

export default Business;
