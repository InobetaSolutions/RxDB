const nano = require('nano')('http://admin:admin@13.50.203.154:5984');
const { MongoClient } = require('mongodb');

const couchDb = nano.db.use('couchdb');
const mongoUri =
    'https://regenextwrpl01:HFr1UcQRI4lHgoNP@cluster0.jjn9m9k.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
const mongoClient = new MongoClient(mongoUri);

const mongoDbName = 'BusinessDB';
const mongoCollectionName = 'Business';

async function sync() {
    try {
        await mongoClient.connect();
        const mongoDb = mongoClient.db(mongoDbName);
        const mongoCol = mongoDb.collection(mongoCollectionName);

        const follow = require('follow');
        const feed = new follow.Feed({
            db: 'http://admin:admin@13.50.203.154:5984/couchdb',
            include_docs: true,
            since: 'now',
        });

        feed.on('change', async (change) => {
            try {
                const doc = change.doc;

                // Remove _rev and optionally _id to avoid MongoDB conflicts
                delete doc._rev;
                delete doc._id;

                await mongoCol.updateOne(
                    { id: doc.id },
                    { $set: doc },
                    { upsert: true }
                );

                console.log(
                    `✅ Synced to MongoDB: ID = ${doc.id}, Name = ${doc.name}`
                );
            } catch (err) {
                console.error('❌ Error syncing document:', err);
            }
        });

        feed.on('error', (err) => {
            console.error('❌ Follow error:', err);
        });

        feed.follow();
        console.log('📡 Started syncing CouchDB → MongoDB...');
    } catch (err) {
        console.error('❌ Sync failed:', err);
    }
}

sync();
