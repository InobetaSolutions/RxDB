import { addRxPlugin, createRxDatabase } from "rxdb";
import { getRxStoragePouch, addPouchPlugin } from "rxdb/plugins/pouchdb";
import { replicateRxCollection } from "rxdb/plugins/replication";
import { RxDBDevModePlugin } from "rxdb/plugins/dev-mode";
import { RxDBLeaderElectionPlugin } from "rxdb/plugins/leader-election";
import PouchdbAdapterIdb from "pouchdb-adapter-idb";
import PouchDB from "pouchdb";
 
addRxPlugin(RxDBDevModePlugin);
addRxPlugin(RxDBLeaderElectionPlugin);
addPouchPlugin(PouchdbAdapterIdb);
 
const businessSchema = {
  title: "business schema",
  version: 0,
  primaryKey: "id",
  type: "object",
  properties: {
    id: { type: "string", maxLength: 100 },
    name: { type: "string" },
  },
  required: ["id", "name"],
};
 
let dbPromise = null;
 
export const getDatabase = async () => {
  if (!dbPromise) {
    dbPromise = createRxDatabase({
      name: "couchdb",
      storage: getRxStoragePouch("idb"),
      ignoreDuplicate: true,
    }).then(async (db) => {
      await db.addCollections({
        businesses: { schema: businessSchema },
      });
 
      // Replication setup
      replicateRxCollection({
        collection: db.businesses,
        replicationIdentifier: "businesses-sync",
        pull: {
          async handler(lastCheckpoint, batchSize) {
            const remoteDb = new PouchDB(
              "http://admin:admin@13.50.203.154:5984/couchdb"
            );
            const result = await remoteDb.allDocs({ include_docs: true });
            const docs = result.rows.map((row) => row.doc);
            return { documents: docs, checkpoint: {} };
          },
        },
        push: {
          async handler(rows) {
            const remoteDb = new PouchDB(
              "http://admin:admin@13.50.203.154:5984/couchdb"
            );
            await remoteDb.bulkDocs(rows);
            return {};
          },
        },
        live: true,
        retry: true,
      });
 
      return db;
    });
  }
  return dbPromise;
};